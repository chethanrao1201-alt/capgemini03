import { useEffect, useState } from 'react'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8076'

export default function App() {
  const [certificates, setCertificates] = useState([])
  const [year, setYear] = useState('')
  const [college, setCollege] = useState('')
  const [selectedId, setSelectedId] = useState(null)
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  const getCertificates = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_URL}/getcertificate`)
      if (!response.ok) throw new Error('Failed to fetch certificates')
      const data = await response.json()
      setCertificates(data)
    } catch (error) {
      console.error(error)
      setMessage('Cannot connect to backend. Start Spring Boot on port 8076.')
    } finally {
      setLoading(false)
    }
  }

  const clearForm = () => {
    setYear('')
    setCollege('')
    setSelectedId(null)
  }

  const saveCertificate = async (event) => {
    event.preventDefault()
    if (!year || !college.trim()) {
      setMessage('Please enter year and college.')
      return
    }

    try {
      const response = await fetch(`${API_URL}/savecertificate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ year: Number(year), college: college.trim() })
      })
      if (!response.ok) throw new Error('Save failed')
      setMessage('Certificate saved successfully.')
      clearForm()
      await getCertificates()
    } catch (error) {
      console.error(error)
      setMessage('Failed to save certificate.')
    }
  }

  const editCertificate = (certificate) => {
    setSelectedId(certificate.id)
    setYear(certificate.year)
    setCollege(certificate.college)
    setMessage(`Certificate #${certificate.id} selected.`)
  }

  const updateCertificate = async (event) => {
    event.preventDefault()
    if (selectedId === null) {
      setMessage('Select a certificate from the table first.')
      return
    }
    if (!year || !college.trim()) {
      setMessage('Please enter year and college.')
      return
    }

    try {
      const response = await fetch(`${API_URL}/updatecertificate/${selectedId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ year: Number(year), college: college.trim() })
      })
      if (!response.ok) throw new Error('Update failed')
      setMessage('Certificate updated successfully.')
      clearForm()
      await getCertificates()
    } catch (error) {
      console.error(error)
      setMessage('Failed to update certificate.')
    }
  }

  const deleteCertificate = async (id) => {
    if (id === null) {
      setMessage('Select a certificate from the table first.')
      return
    }

    if (!window.confirm(`Delete certificate #${id}?`)) return

    try {
      const response = await fetch(`${API_URL}/deletecertificate/${id}`, {
        method: 'DELETE'
      })
      if (!response.ok) throw new Error('Delete failed')
      setMessage('Certificate deleted successfully.')
      clearForm()
      await getCertificates()
    } catch (error) {
      console.error(error)
      setMessage('Failed to delete certificate.')
    }
  }

  useEffect(() => {
    getCertificates()
  }, [])

  return (
    <main className="container">
      <header className="page-header">
        <div>
          <p className="eyebrow">PLACEMENT MANAGEMENT</p>
          <h1>Certificate Management System</h1>
        </div>
      </header>

      <section className="card">
        <div className="card-title">
          <h2>{selectedId === null ? 'Add Certificate' : `Selected Certificate #${selectedId}`}</h2>
        </div>

        <form>
          <div className="form-grid">
            <label>
              Year
              <input
                type="number"
                min="1900"
                max="2100"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                placeholder="2026"
              />
            </label>

            <label>
              College
              <input
                type="text"
                value={college}
                onChange={(e) => setCollege(e.target.value)}
                placeholder="Sri Siddhartha Institute of Technology"
              />
            </label>
          </div>

          <div className="actions">
            <button className="primary" type="button" onClick={saveCertificate}>
              Save Certificate
            </button>

            <button className="update" type="button" onClick={updateCertificate}>
              Update Certificate
            </button>

            <button
              className="danger"
              type="button"
              onClick={() => deleteCertificate(selectedId)}
            >
              Delete Certificate
            </button>
          </div>
        </form>

        {message && <p className="message">{message}</p>}
      </section>

      <section className="card">
        <div className="card-title">
          <h2>Certificate List</h2>
          <span className="count">{certificates.length} record{certificates.length === 1 ? '' : 's'}</span>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Year</th>
                <th>College</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {certificates.length === 0 ? (
                <tr>
                  <td colSpan="4" className="empty">{loading ? 'Loading...' : 'No certificates found.'}</td>
                </tr>
              ) : certificates.map((certificate) => (
                <tr key={certificate.id}>
                  <td>{certificate.id}</td>
                  <td>{certificate.year}</td>
                  <td>{certificate.college}</td>
                  <td className="row-actions">
                    <button className="edit" onClick={() => editCertificate(certificate)}>
                      Edit
                    </button>
                    <button className="danger" onClick={() => deleteCertificate(certificate.id)}>
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  )
}
