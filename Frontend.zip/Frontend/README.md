# Certificate Frontend

React + Vite frontend for the Placement Certificate Management backend.

## Run

```powershell
npm install
npm run dev
```

Frontend: `http://localhost:5173/`

Backend API: `http://localhost:8076/`

The API URL is configured in `.env`:

```text
VITE_API_URL=http://localhost:8076
```
